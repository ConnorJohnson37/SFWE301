import java.util.Scanner;

// Run this only, nothing else
public class Main {
    public static void main(String[] args) throws Exception {
        HomePageGUI gui = new HomePageGUI();
    }
}
