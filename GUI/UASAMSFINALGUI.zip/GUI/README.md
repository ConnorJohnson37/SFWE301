## Getting Started

This is the final product of the UASAMS system for SFWE 301. This does not require a package as this was the only way we were all able to run the code without issues.
To run this project in VSCode, only run the Main.java file using the "Run Java" button on the top right when on the Main.java. This should work and automatically pop up a 
GUI that tells you to choose a certain login. The rest can be done from there.

To login as an admin:
username: Admin (case sensitive)
password: password

To login as a user:
username: Connor (case sensitive)
password: password

Thank you and godspeed and have fun with using this system,
SFWE 301 Team 1
